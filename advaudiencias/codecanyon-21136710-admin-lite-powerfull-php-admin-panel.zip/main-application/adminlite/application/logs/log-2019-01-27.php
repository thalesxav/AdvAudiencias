<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-01-27 10:52:18 --> 404 Page Not Found: Pages/invoice
ERROR - 2019-01-27 10:53:26 --> 404 Page Not Found: Pages/profile
ERROR - 2019-01-27 10:56:26 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1126
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1126
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1202
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1206
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1406
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1410
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1126
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1126
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1202
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1206
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1406
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1410
ERROR - 2019-01-27 10:57:40 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\adminlite\application\helpers\mpdf\mpdf.php 32511
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1126
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1126
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1202
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1206
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1406
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1410
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1126
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Cannot assign an empty string to a string offset C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1126
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1202
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1206
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1406
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> Illegal string offset 'ID' C:\wamp64\www\adminlite\application\helpers\mpdf\classes\cssmgr.php 1410
ERROR - 2019-01-27 10:58:07 --> Severity: Warning --> A non-numeric value encountered C:\wamp64\www\adminlite\application\helpers\mpdf\mpdf.php 32511
ERROR - 2019-01-27 11:00:11 --> Severity: Notice --> Undefined property: Export::$ignore_directories C:\wamp64\www\adminlite\application\controllers\admin\Export.php 23
ERROR - 2019-01-27 11:00:11 --> Severity: Notice --> Only variables should be assigned by reference C:\wamp64\www\adminlite\application\controllers\admin\Export.php 29
ERROR - 2019-01-27 16:23:57 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:24:00 --> 404 Page Not Found: Access_denied/L2FkbWlubGl0ZS9hZG1pbi9hZG1pbi9lZGl0LzMw
ERROR - 2019-01-27 16:24:15 --> 404 Page Not Found: Access_denied/L2FkbWlubGl0ZS9hZG1pbi9hZG1pbi9lZGl0LzMw
ERROR - 2019-01-27 16:24:19 --> 404 Page Not Found: Access_denied/index
ERROR - 2019-01-27 16:24:23 --> 404 Page Not Found: Access_denied/index
ERROR - 2019-01-27 16:25:04 --> 404 Page Not Found: Access_denied/L2FkbWlubGl0ZS9hZG1pbi9hZG1pbi9lZGl0LzMw
ERROR - 2019-01-27 16:25:54 --> 404 Page Not Found: Access_denied/L2FkbWlubGl0ZS9hZG1pbi9hZG1pbi9lZGl0LzMw
ERROR - 2019-01-27 16:26:45 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:32:30 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\wamp64\www\adminlite\application\libraries\Rbac.php 48
ERROR - 2019-01-27 16:32:52 --> Severity: error --> Exception: syntax error, unexpected '' (T_ENCAPSED_AND_WHITESPACE), expecting '-' or identifier (T_STRING) or variable (T_VARIABLE) or number (T_NUM_STRING) C:\wamp64\www\adminlite\application\libraries\Rbac.php 59
ERROR - 2019-01-27 16:33:19 --> Severity: Notice --> Undefined variable: back_to C:\wamp64\www\adminlite\application\libraries\Rbac.php 60
ERROR - 2019-01-27 16:35:09 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:35:13 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:36:35 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:39:28 --> 404 Page Not Found: Adminlite/admin
ERROR - 2019-01-27 16:39:37 --> 404 Page Not Found: Adminlite/admin
ERROR - 2019-01-27 16:41:44 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:52:07 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:52:41 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:52:54 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:54:17 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:54:44 --> 404 Page Not Found: admin/List/index
ERROR - 2019-01-27 16:54:49 --> 404 Page Not Found: admin/List/index
ERROR - 2019-01-27 16:54:55 --> 404 Page Not Found: admin/List/index
ERROR - 2019-01-27 16:55:26 --> 404 Page Not Found: Theme/common
ERROR - 2019-01-27 16:55:59 --> 404 Page Not Found: Theme/common
