<?php
$name='DejaVuSerifCondensed';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 4,
  'FontBBox' => '[-693 -347 1512 1242]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 540.0,
);
$up=-63;
$ut=44;
$ttffile='C:/wamp64/www/codegrape_jobportal/application/helpers/mpdf/ttfonts/DejaVuSerifCondensed.ttf';
$TTCfontID='0';
$originalsize=296976;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavuserifcondensed';
$panose=' 0 0 2 6 6 6 5 6 5 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>